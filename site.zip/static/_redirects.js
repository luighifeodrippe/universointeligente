# http and https need separate rules if you don’t force_ssl!
https://fiquesabendo.netlify.app/* https://www.nesseuniverso.com/:splat 301!
https://fiquesabendo.netlify.app/* http://nesseuniverso.com/:splat 301!
https://fiquesabendo.netlify.app/* www.nesseuniverso.com/:splat 301!
